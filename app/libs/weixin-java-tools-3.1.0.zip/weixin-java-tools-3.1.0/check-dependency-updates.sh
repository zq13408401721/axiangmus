#!/usr/bin/env bash
./mvnw org.codehaus.mojo:versions-maven-plugin:display-dependency-updates
